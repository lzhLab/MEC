./configure --with-sparsehash=/home/lzh/Local/tools/sparsehash/build
