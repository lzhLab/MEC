#ifndef MASK_H
#define MASK_H

#include <string>
#include <stdint.h>

//@--START lzhao--
extern uint32_t* glz_pReadMask;
namespace Mask
{
    void initReadsMask(std::string readsFileDim);
    void cleanReadsMask();
    size_t getCell(size_t index);
    void setCell(size_t index);
}
//@--END lzhao--
#endif
