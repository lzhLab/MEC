//-----------------------------------------------
// Copyright 2016 Guangxi University
// Written by Liang Zhao(S080011@e.ntu.edu.sg)
// Released under the GPL
//-----------------------------------------------
//
// candidate - Obtain the candidate erroneous bases of input reads 
// It's developed based on SGA originally writen by Jared Simpson (js18@sanger.ac.uk)
//
#ifndef CANDIDATE_H
#define CANDIDATE_H
#include <getopt.h>
#include "config.h"
#include "BWT.h"
#include "Match.h"
#include "BWTAlgorithms.h"
#include "gzstream.h"

// functions

//
int candidateMain(int argc, char** argv);

// options
void parseCandidateOptions(int argc, char** argv);

#endif
