//-----------------------------------------------
// Copyright 2016 Guangxi University
// Written by Liang Zhao(S080011@e.ntu.edu.sg)
// Released under the GPL
//-----------------------------------------------
//
// correct - Correct sequencing errors in reads 
//

#ifndef CORRECT_H
#define CORRECT_H
#include <getopt.h>
#include "config.h"

// functions

//
int correctMain(int argc, char** argv);

// options
void parseCorrectOptions(int argc, char** argv);

#endif
